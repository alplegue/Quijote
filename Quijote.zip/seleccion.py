# -*- coding: utf-8 -*-

"""
Álvaro PLeguezuelos Escobar

"""

import random
import sys

def main(archivo, nombrearchivosalida, ratio):  #el ratio está entre 0 y 1

    with open(archivo) as archivo1:
        
        with open(nombrearchivosalida, 'w') as archivo2:
            
            for linea in archivo1:
                
                if random.random()<=ratio:
                    
                    archivo2.write(linea)


if __name__=="__main__":
    
    if len(sys.argv)<4:
        
        print(f"Hemos hecho uso de: {sys.argv[0]} <archivo> <nombrearchivosalida> <ratio")
        
        sys.exit(0)
        
    archivo = sys.argv[1]
    
    nombrearchivosalida = sys.argv[2]
    
    ratio = float(sys.argv[3])
    
    main(archivo, nombrearchivosalida, ratio)
